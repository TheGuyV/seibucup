#!/usr/bin/env python3
"""
Apply the Seibu Cup Soccer COP3 fixes to MAME's seibucop sources.

Usage: python apply_patch.py <src_dir> <out_dir>
  src_dir : directory holding pristine seibucop.cpp / .h / _cmd.ipp / _dma.ipp
  out_dir : where the patched copies are written

Every replacement asserts that its anchor text occurs exactly once, so a
MAME upstream change that moves the anchor fails loudly instead of silently
producing a half-applied patch.

Source of truth for the behavioural changes: rmonic79's MiSTer core
(rtl/SeibuCup/SeibuCup_cop3.sv), verified against real hardware, and the
analysis in docs/01_cop3_diff.md.
"""
import sys
import os
import re


def rep(text, old, new, count=1, label=""):
    n = text.count(old)
    if n != count:
        raise SystemExit(f"anchor '{label or old[:60]!r}' found {n} times, expected {count}")
    return text.replace(old, new)


def replace_function(text, signature, new_body, label):
    """Replace a whole top-level function: from `signature` to the first '\n}\n' after it."""
    start = text.find(signature)
    if start < 0 or text.find(signature, start + 1) >= 0:
        raise SystemExit(f"function anchor {label} not unique/found")
    end = text.find("\n}\n", start)
    if end < 0:
        raise SystemExit(f"function end for {label} not found")
    end += len("\n}\n")
    return text[:start] + new_body + text[end:]


# --------------------------------------------------------------------------
# seibucop.cpp
# --------------------------------------------------------------------------
def patch_cpp(t):
    # (a) clear bit 15 on every command, like cop_cmd_w does
    t = rep(t,
        "\tcommand = find_trigger_match(data, 0xf800);\n\n\n\tif (command == -1)\n\t{\n\t\treturn;\n\t}\n",
        "\tcommand = find_trigger_match(data, 0xf800);\n\n\n\tif (command == -1)\n\t{\n\t\treturn;\n\t}\n\n"
        "\t// a new command clears the exception flag, same as cop_cmd_w\n"
        "\tcop_status &= 0x7fff;\n",
        label="cmd_w bit15 clear")

    # (e) slot 06 (330e/338e) cupsoc/grainbow microcode: same maths and registers as slot 02
    t = rep(t,
        "\t/* Pythagorean theorem, hypotenuse direction - 130e / 138e */\n",
        "\t/* 0x330e / 0x338e, slot 06 variant (cupsoc, grainbow): same maths and registers as slot 02 */\n"
        "\tif (check_command_matches(command, 0x984, 0xaa4, 0xd82, 0xaa2, 0x39c, 0xb9c, 0xb9c, 0xa9a, 5, 0xbf7f))\n"
        "\t{\n\t\texecuted = 1;\n\t\tLEGACY_execute_130e_cupsoc(offset, data);\n\t\treturn;\n\t}\n\n"
        "\t/* Pythagorean theorem, hypotenuse direction - 130e / 138e */\n",
        label="slot06 dispatch")

    # (b) 5105
    t = rep(t,
        "\tif (check_command_matches(command, 0xa80, 0x984, 0x082, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfefb))\n"
        "\t{\n\t\t//executed = 1;\n\t\tprintf(\"5105\\n\");\n\t\treturn;\n\t}\n",
        "\t// (cupsoc) 0a | 5 | fefb | 5105 | a80 984 082 : 16.16 multiply by the operand at 0x446/0x448\n"
        "\tif (check_command_matches(command, 0xa80, 0x984, 0x082, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfefb))\n"
        "\t{\n\t\texecuted = 1;\n\t\texecute_5105(offset, data);\n\t\treturn;\n\t}\n",
        label="5105 dispatch")

    # (c) 5905
    t = rep(t,
        "\tif (check_command_matches(command, 0x9c8, 0xa84, 0x0a2, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfffb))\n"
        "\t{\n\t\t//executed = 1;\n\t\tprintf(\"5905\\n\");\n\t\treturn;\n\t}\n",
        "\t// (cupsoc) 0b | 5 | fffb | 5905 | 9c8 a84 0a2 : 16.16 multiply, r2+0x10 -> r1+0x04\n"
        "\tif (check_command_matches(command, 0x9c8, 0xa84, 0x0a2, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfffb))\n"
        "\t{\n\t\texecuted = 1;\n\t\texecute_5905(offset, data);\n\t\treturn;\n\t}\n",
        label="5905 dispatch")

    # (d) f105
    t = rep(t,
        "\t// player to ball collision\n"
        "\tif (check_command_matches(command, 0xa88, 0x994, 0x088, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfefb))\n"
        "\t{\n\t\texecute_f105(offset,data);\n\t\treturn;\n\t}\n",
        "\t// (cupsoc) 1e | 5 | fefb | f105 | a88 994 088 : 16.16 multiply in place on r0+0x10 (velocity damping, K is always 0xC000 = 0.75)\n"
        "\tif (check_command_matches(command, 0xa88, 0x994, 0x088, 0x000, 0x000, 0x000, 0x000, 0x000, 5, 0xfefb))\n"
        "\t{\n\t\texecuted = 1;\n\t\texecute_f105(offset, data);\n\t\treturn;\n\t}\n",
        label="f105 dispatch")

    # (f) PRNG. The old code returned total_cycles() % (max+1); cupsoc reads this at a fixed
    # per-frame cadence, so the sequence locked into a handful of residues and spawns waiting
    # for a specific value (stage 4 boss) never triggered. A 16-bit maximal LFSR advanced on
    # every read (as the MiSTer core does, matching the real chip) is well distributed AND
    # deterministic - the latter matters for save states, input record/playback, and netplay.
    # machine().rand() must NOT be used here: it is a machine-global generator that MAME also
    # advances from render/throttle code, so it desyncs the emulation (see emu/screen.cpp).
    t = rep(t,
        "uint16_t raiden2cop_device::cop_prng_r()\n{\n"
        "\treturn m_host_cpu->total_cycles() % (m_cop_rng_max_value + 1);\n}\n",
        "uint16_t raiden2cop_device::cop_prng_r()\n{\n"
        "\t// 16-bit maximal LFSR (taps 16,15,13,4), advanced once per read, then scaled to\n"
        "\t// 0..max by multiply-shift (a bare mask would drop bits for non-2^n-1 maxima such\n"
        "\t// as cupsoc's 99). Seeded at construction and saved in the device state, so it is\n"
        "\t// identical across machines after a state load - required for deterministic netplay.\n"
        "\tu16 const bit = ((m_prng_lfsr >> 15) ^ (m_prng_lfsr >> 14) ^ (m_prng_lfsr >> 12) ^ (m_prng_lfsr >> 3)) & 1;\n"
        "\tm_prng_lfsr = u16((m_prng_lfsr << 1) | bit);\n"
        "\treturn u16((u32(m_prng_lfsr) * (m_cop_rng_max_value + 1)) >> 16);\n}\n",
        label="prng")

    # (f2) persist the LFSR in the device save state so a netplay state sync transfers it
    t = rep(t,
        "\tsave_item(NAME(m_cop_rng_max_value));\n",
        "\tsave_item(NAME(m_cop_rng_max_value));\n\tsave_item(NAME(m_prng_lfsr));\n",
        label="prng save_item")

    # register naming: 0x446/0x448 hold the multiplier operand, not a ROM address
    t = rep(t,
        "// cupsoc writes a longword before 0x5105 or 0xF105 (always 0xC000 for the latter)\n",
        "// cupsoc writes a longword here before 0x5105/0x5905/0xF105/0xD104: it is the 16.16 fixed point\n"
        "// multiplier operand of those commands (0xC000 = 0.75 for 0xF105, 0xD554 = 5/6, 2/|g| for jumps...),\n"
        "// not a ROM address. Names kept for save state compatibility.\n",
        label="operand comment")
    return t


# --------------------------------------------------------------------------
# seibucop_cmd.ipp
# --------------------------------------------------------------------------
ANGLE_CUPSOC_BODY = r'''void raiden2cop_device::LEGACY_execute_130e_cupsoc(int offset, uint16_t data)
{
	// second point: reg1 (zone target) for slot 02/06, reg2 (the ball) for slot 1c (e18e/e30e/e38e)
	const int second_reg = ((data & 0xf800) == 0xe000) ? 2 : 1;
	int dy = m_host_space->read_dword(cop_regs[second_reg] + 4) - m_host_space->read_dword(cop_regs[0] + 4);
	int dx = m_host_space->read_dword(cop_regs[second_reg] + 8) - m_host_space->read_dword(cop_regs[0] + 8);

	cop_status = 7;

	if (!dx) {
		cop_angle = 0;
	}
	else
	{
		cop_angle = (int)(atan(double(dy) / double(dx)) * 128.0 / std::numbers::pi);
		if (dx < 0)
			cop_angle += 0x80;

		cop_angle &= 0xff;
	}

	// The exception flag looks at the integer part only: the chip works in pixels
	// (the bootleg tables index distance/angle by 9-bit integer coordinates, and 3bb0
	// truncates the deltas with >>16 as well). With the full 32-bit test the game never
	// ran its own fallback ($006344, forcing a cardinal angle where cos is exactly 0)
	// and the camera following the ball on a throw-in oscillated by 1px every frame.
	if ((dx >> 16) == 0)
		cop_status |= 0x8000;

	// keep the deltas for the distance command (3bb0) that follows
	m_LEGACY_r0 = dy;
	m_LEGACY_r1 = dx;

	// Whether the angle is written back is decided by the microcode length field
	// (((data >> 7) & 7) + 1 words), not by bit 7:
	//   118e / e18e  len 4  load the deltas only
	//   130e / e30e  len 7  compute the angle, keep it in cop_angle
	//   138e / e38e  len 8  compute and write to the object
	// e18e runs on every object every frame between the movement and the facing
	// update; with the bit 7 rule it clobbered the facing byte and players walked
	// correctly while facing the wrong way.
	// The write is skipped when dx == 0 (confirmed on hardware by the MiSTer core).
	if (((data >> 7) & 7) == 7 && dx != 0)
		cop_write_byte(cop_regs[0] + 0x34, cop_angle);
}
'''

E30E_BODY = r'''// controls GK position, aligned to the ball position (reg2 = ball); see LEGACY_execute_130e_cupsoc
void raiden2cop_device::LEGACY_execute_e30e(int offset, uint16_t data)
{
	LEGACY_execute_130e_cupsoc(offset, data);
}
'''

LEGACY_6200_BODY = r'''void raiden2cop_device::LEGACY_execute_6200(int offset, uint16_t data) // this is for cupsoc, different sequence, works on different registers
{
	int primary_reg = 1;
	int primary_offset = 0xc;

	uint8_t angle = cop_read_byte(cop_regs[primary_reg] + primary_offset);
	uint16_t flags = cop_read_word(cop_regs[primary_reg]);
	cop_angle_target &= 0xff;
	cop_angle_step &= 0xff;
	flags &= ~0x0004;
	int delta = angle - cop_angle_target;
	if (delta >= 128)
		delta -= 256;
	else if (delta < -128)
		delta += 256;
	if (delta < 0) {
		if (delta >= -cop_angle_step) {
			angle = cop_angle_target;
			flags |= 0x0004;
		}
		else
			angle += cop_angle_step;
	}
	else {
		if (delta <= cop_angle_step) {
			angle = cop_angle_target;
			flags |= 0x0004;
		}
		else
			angle -= cop_angle_step;
	}

	cop_write_word(cop_regs[primary_reg], flags);

	// Byte write only. A word write also zeroes the neighbouring byte (host +0x0e),
	// which holds the body angle that $0134CE copies into the sprite: players then
	// face random directions.
	cop_write_byte(cop_regs[primary_reg] + primary_offset, angle);
}
'''

D104_BODY = r'''void raiden2cop_device::LEGACY_execute_d104(int offset, uint16_t data)
{
	// Zone target for a player, in 16.16:
	//   dst[r1 + 4 + 4n] = (ball[r2 + 4 + 4n] - origin[r3 + 4n]) * K >> 16
	// r2 = the ball object, r1 = player object + 0x40, r3 = the pitch origin
	// ({1056.0, 384.0} loaded from ROM), K = the operand at 0x446/0x448.
	// Right after this the 68000 adds the zone minimum. Without it the target
	// field is never refreshed and players chase a point that drifts off the pitch.
	const uint32_t off = offset * 4;
	const int64_t k = int32_t((uint32_t(m_cop_rom_addr_hi) << 16) | m_cop_rom_addr_lo);
	const int64_t src = int32_t(m_host_space->read_dword(cop_regs[2] + 4 + off));
	const int64_t org = int32_t(m_host_space->read_dword(cop_regs[3] + off));
	m_host_space->write_dword(cop_regs[1] + 4 + off, uint32_t(((src - org) * k) >> 16));
}
'''

MUL_BODY = r'''// 16.16 fixed point multiply used by cupsoc: dst = src * K >> 16, with K the longword
// written to 0x446/0x448 just before the command. Derived from the program ROM
// ($01C95C writes the operand, triggers 5105, reads the product back and adds it to
// a position, so the result is already 16.16) and verified on hardware by the
// MiSTer core. Truncation is floor (arithmetic shift): 2/|g| = 802497.6 is stored
// in ROM as 802497.
void raiden2cop_device::cop_mul_16_16(uint32_t src, uint32_t dst)
{
	const int64_t a = int32_t(m_host_space->read_dword(src));
	const int64_t k = int32_t((uint32_t(m_cop_rom_addr_hi) << 16) | m_cop_rom_addr_lo);
	m_host_space->write_dword(dst, uint32_t((a * k) >> 16));
}

/*
[:raiden2cop] COPDIS: 5105 s=50 f1=0 l=3 f2=05 5 fefb 50 a80 15.0.00 [:raiden2cop] sub32 (r0)
[:raiden2cop] COPDIS: 5105 s=50 f1=0 l=3 f2=05 5 fefb 51 984 13.0.04 [:raiden2cop] write16h 8(r0)
[:raiden2cop] COPDIS: 5105 s=50 f1=0 l=3 f2=05 5 fefb 52 082 01.0.02 [:raiden2cop] addmem32 4(r0)
*/
// r0+0x00 -> r0+0x04 (flight time = (2/g) * Vz and other generic chains)
void raiden2cop_device::execute_5105(int offset, uint16_t data)
{
	cop_mul_16_16(cop_regs[0] + 0x00 + offset * 4, cop_regs[0] + 0x04 + offset * 4);
}

/*
[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 58 9c8 13.2.08 [:raiden2cop] write16h 10(r2)
[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 59 a84 15.0.04 [:raiden2cop] sub32 8(r0)
[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 5a 0a2 01.1.02 [:raiden2cop] addmem32 4(r1)
*/
// r2+0x10 -> r1+0x04 (V * t = displacement; r2 = ball object, r1 = object + 0x40)
void raiden2cop_device::execute_5905(int offset, uint16_t data)
{
	cop_mul_16_16(cop_regs[2] + 0x10 + offset * 4, cop_regs[1] + 0x04 + offset * 4);
}

/*
[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f0 a88 15.0.08 [:raiden2cop] sub32 10(r0)
[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f1 994 13.0.14 [:raiden2cop] write16h 28(r0)
[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f2 088 01.0.08 [:raiden2cop] addmem32 10(r0)
*/
// r0+0x10 in place (velocity damping, the game always uses K = 0xC000 = 0.75)
void raiden2cop_device::execute_f105(int offset, uint16_t data)
{
	cop_mul_16_16(cop_regs[0] + 0x10 + offset * 4, cop_regs[0] + 0x10 + offset * 4);
}
'''


def patch_cmd(t):
    # (h) 0204 = 0205 with the velocity subtracted
    t = rep(t,
        "\tint ppos =        m_host_space->read_dword(cop_regs[0] + 0x04 + offset * 4);\n"
        "\tint npos = ppos + m_host_space->read_dword(cop_regs[0] + 0x10 + offset * 4);\n",
        "\tint ppos = m_host_space->read_dword(cop_regs[0] + 0x04 + offset * 4);\n"
        "\tint vel  = m_host_space->read_dword(cop_regs[0] + 0x10 + offset * 4);\n"
        "\t// bit 0 clear (0204): step backwards. cupsoc uses it to undo the step just\n"
        "\t// applied when an object ends up outside the pitch; adding doubled the step.\n"
        "\tint npos = (data & 1) ? ppos + vel : ppos - vel;\n",
        label="0205/0204")

    # (i) cupsoc angle command
    t = replace_function(t, "void raiden2cop_device::LEGACY_execute_130e_cupsoc(int offset, uint16_t data)\n{",
                         ANGLE_CUPSOC_BODY, "130e_cupsoc")

    # (j) execute_338e: latch deltas for 3bb0
    t = rep(t,
        "\tint dx = m_host_space->read_dword(cop_regs[1] + 4) - m_host_space->read_dword(cop_regs[0] + 4);\n"
        "\tint dy = m_host_space->read_dword(cop_regs[1] + 8) - m_host_space->read_dword(cop_regs[0] + 8);\n\n"
        "\tcop_status = 7;\n\n\tif (!dy) {\n\t\tcop_status |= 0x8000;\n\t\tcop_angle = 0;\n\t}\n\telse {\n"
        "\t\tcop_angle = (int)(atan(double(dx) / double(dy)) * 128 / std::numbers::pi);\n",
        "\tint dx = m_host_space->read_dword(cop_regs[1] + 4) - m_host_space->read_dword(cop_regs[0] + 4);\n"
        "\tint dy = m_host_space->read_dword(cop_regs[1] + 8) - m_host_space->read_dword(cop_regs[0] + 8);\n\n"
        "\t// keep the deltas for the distance command (3bb0) that follows\n"
        "\tm_LEGACY_r0 = dx;\n\tm_LEGACY_r1 = dy;\n\n"
        "\tcop_status = 7;\n\n\tif (!dy) {\n\t\tcop_status |= 0x8000;\n\t\tcop_angle = 0;\n\t}\n\telse {\n"
        "\t\tcop_angle = (int)(atan(double(dx) / double(dy)) * 128 / std::numbers::pi);\n",
        label="338e latch")

    # (k) 3bb0 uses the latched deltas
    t = rep(t,
        "\t/* TODO: these are actually internally loaded via 0x330e/0x130e command */\n"
        "\tint dx, dy;\n\n"
        "\tdx = m_host_space->read_dword(cop_regs[1] + 4) - m_host_space->read_dword(cop_regs[0] + 4);\n"
        "\tdy = m_host_space->read_dword(cop_regs[1] + 8) - m_host_space->read_dword(cop_regs[0] + 8);\n",
        "\t// The deltas are the ones latched by the last angle command (130e/138e/338e/e30e\n"
        "\t// family), not recomputed from the registers: cupsoc runs e30e (ball, reg2) then\n"
        "\t// 3bb0 and expects the distance to the ball while reg1 still points to the zone\n"
        "\t// target. Recomputing made the contact gate (dist < 0x3c) fail almost always and\n"
        "\t// players walked through the ball.\n"
        "\tint dx = m_LEGACY_r0;\n\tint dy = m_LEGACY_r1;\n",
        label="3bb0 latched")

    # (l) cupsoc 6200 writes a byte
    t = replace_function(t, "void raiden2cop_device::LEGACY_execute_6200(int offset, uint16_t data)",
                         LEGACY_6200_BODY, "LEGACY_6200")

    # (m) d104
    t = replace_function(t, "void raiden2cop_device::LEGACY_execute_d104(int offset, uint16_t data)\n{",
                         D104_BODY, "d104")

    # (n) e30e shares the cupsoc angle code
    t = rep(t,
        "// controls GK position, aligned to the ball position\n"
        "void raiden2cop_device::LEGACY_execute_e30e(int offset, uint16_t data)\n{",
        "@@E30E@@\n{", label="e30e sig")
    t = replace_function(t, "@@E30E@@\n{", E30E_BODY, "e30e")

    # (o) f105 + new 5105/5905 + helper
    t = rep(t,
        "/*\n[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f0 a88 15.0.08 [:raiden2cop] sub32 10(r0)\n"
        "[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f1 994 13.0.14 [:raiden2cop] write16h 28(r0)\n"
        "[:raiden2cop] COPDIS: f105 s=f0 f1=0 l=3 f2=05 5 fefb f2 088 01.0.08 [:raiden2cop] addmem32 10(r0)\n*/\n"
        "// seibu cup soccer, before cosine (ball dribbling actually?)\n"
        "void raiden2cop_device::execute_f105(int offset, uint16_t data)\n{\n\t// ...\n}\n",
        MUL_BODY, label="f105 impl")

    # (p) drop the never-compiled guesses that now clash by name
    t = rep(t,
        "// used by seibu cup soccer, not sure if right so left out\n"
        "void raiden2cop_device::execute_5105(int offset, uint16_t data)\n{\n"
        "\tint res = m_host_space->read_dword(cop_regs[0]) +  m_host_space->read_dword(cop_regs[0]+8);\n"
        "\tm_host_space->write_dword(cop_regs[0]+4, res);\n}\n\n"
        "/*\n[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 58 9c8 13.2.08 [:raiden2cop] write16h 10(r2)\n"
        "[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 59 a84 15.0.04 [:raiden2cop] sub32 8(r0)\n"
        "[:raiden2cop] COPDIS: 5905 s=58 f1=0 l=3 f2=05 5 fffb 5a 0a2 01.1.02 [:raiden2cop] addmem32 4(r1)\n*/\n"
        "void raiden2cop_device::execute_5905(int offset, uint16_t data)\n{\n"
        "\tint res = m_host_space->read_dword(cop_regs[2]+10 + offset*4) - m_host_space->read_dword(cop_regs[0]+8 + offset*4);\n"
        "\tm_host_space->write_dword(cop_regs[1]+4 + offset *4, res);\n}\n\n",
        "", label="unused 5105/5905 stubs")

    # (q) sin/cos: floor, as the bootleg tables describe ("val = trunc(s*amp); if(s<0) val--")
    t = rep(t,
        "\tres = int(amp*sin(angle)) << cop_scale;\n",
        "\t// floor, not truncation toward zero: the bootleg lookup tables decrement the\n"
        "\t// truncated value for negative results (see the notes in LEGACY_cop_cmd_w)\n"
        "\tres = int(floor(amp*sin(angle))) << cop_scale;\n", label="sin floor")
    t = rep(t,
        "\tres = int(amp*cos(angle)) << cop_scale;\n",
        "\tres = int(floor(amp*cos(angle))) << cop_scale;\n", label="cos floor")

    # (g) c480: the clip register is signed
    t = rep(t,
        "\t// save into internal clip register, cfr. increment DMA register $410\n"
        "\tm_sprite_dma_x_clip = sprite_x;\n",
        "\t// save into internal clip register, cfr. increment DMA register $410\n"
        "\t// signed: the [-160, 320) window in cop_sprite_dma_inc_w is meant to include\n"
        "\t// sprites partially off the left edge (an unsigned compare regressed on hardware)\n"
        "\tm_sprite_dma_x_clip = int16_t(sprite_x);\n", label="c480 clip")
    return t


# --------------------------------------------------------------------------
# seibucop_dma.ipp
# --------------------------------------------------------------------------
ZSORT_BODY = r'''void raiden2cop_device::dma_zsorting(uint16_t data)
{
	struct sort_entry {
		int32_t sorting_key;
		uint16_t val;
	};

	// The trigger value is the last index, not the count: cupsoc sorts a 60 entry
	// list with data = 59 ($00364C: move.w $4(a0),d1 / subq.w #1,d1).
	// TODO: only verified on the 68000 games; kept as-is for the V30 ones (zeroteam).
	const int n = m_host_endian ? data + 1 : data;

	std::vector<sort_entry> entries(n);
	for(int i=0; i<n; i++) {
		sort_entry &e = entries[i];
		e.val = m_host_space->read_word(cop_sort_lookup + 2*i);
		if (m_host_endian)
		{
			// The key is the signed word at the longword-aligned address. Both users in
			// cupsoc agree: the plane sort ($00363E, ram = $110004, val = 0 mod 4) keys on
			// the Y integer word at +4, the contact sort ($006A98, ram = $11003A, val = 2
			// mod 4) keys on the distance word at +$38 written by 3bb0. Reading a longword
			// at the raw address picked +$3a/+$3c there, a field nothing ever writes, so
			// every key was 0 and the sort was inert.
			e.sorting_key = int16_t(m_host_space->read_word((cop_sort_ram_addr + e.val) & ~3));
		}
		else
			e.sorting_key = m_host_space->read_dword(cop_sort_ram_addr + e.val);
	}
	switch(cop_sort_param) {
	case 2:
		std::stable_sort(entries.begin(), entries.end(), [](const auto &a, const auto &b){ return a.sorting_key > b.sorting_key; });
		break;
	case 1:
		std::stable_sort(entries.begin(), entries.end(), [](const auto &a, const auto &b){ return a.sorting_key < b.sorting_key; });
		break;
	}

	for(int i=0; i<n; i++)
		m_host_space->write_word(cop_sort_lookup + 2*i, entries[i].val);
}
'''


def patch_dma(t):
    return replace_function(t, "void raiden2cop_device::dma_zsorting(uint16_t data)\n{", ZSORT_BODY, "zsort")


# --------------------------------------------------------------------------
# seibucop.h
# --------------------------------------------------------------------------
def patch_h(t):
    t = rep(t,
        "\tvoid execute_f105(int offset, uint16_t data);\n",
        "\tvoid execute_f105(int offset, uint16_t data);\n"
        "\tvoid execute_5105(int offset, uint16_t data);\n"
        "\tvoid execute_5905(int offset, uint16_t data);\n"
        "\tvoid cop_mul_16_16(uint32_t src, uint32_t dst);\n",
        label="header decls")

    # deterministic PRNG state (see cop_prng_r); seeded here, persisted via save_item
    t = rep(t,
        "\tuint16_t m_cop_rng_max_value;\n",
        "\tuint16_t m_cop_rng_max_value;\n\tuint16_t m_prng_lfsr = 0xace1;\n",
        label="header prng member")
    return t


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    src, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    for name, fn in (("seibucop.cpp", patch_cpp), ("seibucop_cmd.ipp", patch_cmd),
                     ("seibucop_dma.ipp", patch_dma), ("seibucop.h", patch_h)):
        with open(os.path.join(src, name), "r", newline="") as f:
            text = f.read()
        crlf = "\r\n" in text
        text = text.replace("\r\n", "\n")
        text = fn(text)
        if crlf:
            text = text.replace("\n", "\r\n")
        with open(os.path.join(out, name), "w", newline="") as f:
            f.write(text)
        print(f"patched {name}")


if __name__ == "__main__":
    main()
