﻿Seibu Cup Soccer - web build ("Play now" / 바로 플레이 page)

한국어 안내는 아래에 있습니다.

The "Play now" page runs the same patched MAME 0.289 as the PC package, compiled to WebAssembly
with Emscripten. The two files the page sends to your browser, play/seibucup.js and
play/seibucup.wasm, are built from:

1. the MAME source, tag mame0289 (https://github.com/mamedev/mame/tree/mame0289)
2. this kit's COP3 patch (patch/apply_patch.py, see ../README.txt)
3. web_build.diff in this folder: five small changes that the browser needs
   - src/osd/modules/file/posixsocket.cpp: a WebSocket connect that is still in progress
     (EINPROGRESS) counts as connected, and socket options a browser cannot set are ignored.
   - src/emu/machine.cpp: the browser main loop keeps timer-based timing (SDL switches it to the
     screen refresh), paces the game at 60 frames per second by the clock, and lets Lua's
     periodic callbacks run between frames.
   - src/emu/video.cpp: MAME's own throttle is skipped (the browser loop does the pacing).
   - src/osd/modules/sound/js_sound.js: smaller sound blocks (1024 samples) and a cap on the
     queue, so the sound keeps up with the picture.
   - scripts/genie.lua: Lua's protected calls may catch C++ exceptions, so a Lua error inside
     pcall no longer stops the page.

Build (Linux, WSL or Docker; Emscripten 6.0.10):

  git clone --depth 1 --branch mame0289 https://github.com/mamedev/mame.git
  python3 patch/apply_patch.py mame/src/mame/seibu patched/
  cp patched/* mame/src/mame/seibu/
  cd mame
  patch -p1 < ../web/web_build.diff
  source /path/to/emsdk/emsdk_env.sh
  emmake make SUBTARGET=seibucup SOURCES=src/mame/seibu/legionna.cpp NOWERROR=1 TOOLS=0 REGENIE=1 -j8

The result is seibucup.js + seibucup.wasm.

The page's own files (play.html, play/game.html, play/boot.lua, play/netplay.lua,
play/practice.lua and play/tutorial/) are sent to the browser as they are, in source form.

Licenses: the patched MAME is distributed under the GNU GPL v3 or later (../LICENSE). MAME's own
files keep their licenses (GPL-2.0-or-later, some BSD-3-Clause and others; see legal/ on the site).
The Emscripten runtime is MIT / University of Illinois NCSA, and SDL3 is zlib.
The game ROMs are not part of anything here: each player adds their own, and the ROM stays
in that browser.


-------------------------------------------------------------------------------------------
세이부 컵 사커 - 웹판 ("바로 플레이" 페이지)

"바로 플레이" 페이지는 PC 패키지와 같은 수정판 MAME 0.289를 Emscripten으로 WebAssembly로
빌드해 돌립니다. 페이지가 브라우저로 보내는 play/seibucup.js 와 play/seibucup.wasm 은 다음으로
만듭니다.

1. MAME 소스, mame0289 태그 (https://github.com/mamedev/mame/tree/mame0289)
2. 이 키트의 COP3 패치 (patch/apply_patch.py, ../README.txt 참고)
3. 이 폴더의 web_build.diff: 브라우저에서 돌리기 위한 작은 수정 다섯 곳
   - src/osd/modules/file/posixsocket.cpp: 아직 연결 중(EINPROGRESS)인 웹소켓 연결을 연결된
     것으로 보고, 브라우저가 못 바꾸는 소켓 옵션은 무시합니다.
   - src/emu/machine.cpp: 브라우저 메인 루프가 타이머 방식을 유지하고(SDL 이 화면 갱신 방식으로
     바꿔 버림), 시계로 초당 60프레임에 맞추며, 프레임 사이에 Lua 의 주기 콜백을 돌립니다.
   - src/emu/video.cpp: MAME 자체 속도 조절을 건너뜁니다(브라우저 루프가 맞춤).
   - src/osd/modules/sound/js_sound.js: 소리 블록을 1024 샘플로 줄이고 대기열에 상한을 두어,
     소리가 화면보다 늦지 않게 합니다.
   - scripts/genie.lua: Lua 의 보호 호출이 C++ 예외를 잡을 수 있게 해서, pcall 안의 Lua 오류가
     페이지를 멈추지 않게 합니다.

빌드 (리눅스, WSL 또는 도커, Emscripten 6.0.10): 위 영어 안내의 명령 그대로입니다.
결과물은 seibucup.js + seibucup.wasm 입니다.

페이지 자체 파일(play.html, play/game.html, play/boot.lua, play/netplay.lua, play/practice.lua,
play/tutorial/)은 소스 그대로 브라우저로 보내집니다.

라이선스: 수정판 MAME 는 GNU GPL v3 이상(../LICENSE)으로 배포합니다. MAME 원래 파일들은 각자의
라이선스(GPL-2.0-or-later, 일부 BSD-3-Clause 등, 사이트의 legal/ 참고)를 따릅니다. Emscripten
런타임은 MIT / 일리노이 대학 NCSA, SDL3 는 zlib 라이선스입니다.
게임 롬은 여기 어디에도 들어 있지 않습니다. 각자 넣은 롬은 그 브라우저 안에만 있습니다.
