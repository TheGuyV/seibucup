﻿Seibu Cup Soccer COP3 patch for MAME 0.289

한국어 안내는 아래에 있습니다.

MAME still marks Seibu Cup Soccer (cupsoc) as unemulated protection / not working: the
SEI300 ("COP3") coprocessor commands the game relies on are missing or wrong. This patch
replaces four files in MAME's src/mame/seibu/ with corrected versions, ported from
rmonic79's MiSTer FPGA core (https://github.com/rmonic79/Arcade-SeibuCupSoccer_MiSTer), which
worked the chip out against real hardware. With it the game plays correctly (players walk and
face the right way, the ball can be reached, the depth sort works, matches run to the end).

No MAME executable is distributed here. You build your own copy on your own PC:

One click (Windows 10/11, 64-bit)

1. Unzip this folder inside the netplay package (next to bin\), or anywhere if you only want MAME.
2. Double-click setup_mame.cmd.
3. Wait. It downloads the free MSYS2 compiler environment into this folder (msys64\, nothing
   is installed system-wide), downloads the MAME 0.289 source (about 2 GB), applies the patch,
   compiles just this game's driver (5-40 minutes depending on your CPU) and places mame.exe
   in ..\bin\ (or out\).

It needs roughly 6 GB of free disk space while it works; the compiler and the source are
deleted automatically at the end, only mame.exe stays. Keep the folder in a simple path without spaces or non-English characters (for
example C:\seibucup\). Nothing is uploaded anywhere. Run the script again to resume after a
network hiccup.

Good to know
- No administrator rights are needed: nothing is installed system-wide, everything stays in this
  folder. Do not put the folder under C:\Program Files or another protected location; a plain
  folder such as C:\seibucup is right.
- Windows may show a blue "protected your PC" (SmartScreen) box for the script or for the MSYS2
  installer it downloads. Click "More info" and then "Run anyway". Some antivirus programs slow
  the compile down; that is normal.

By hand


pacman -S git make mingw-w64-x86_64-gcc mingw-w64-x86_64-python mingw-w64-x86_64-lld mingw-w64-x86_64-libc++
git clone --depth 1 --branch mame0289 https://github.com/mamedev/mame.git
python patch/apply_patch.py mame/src/mame/seibu patched/          # writes the 4 patched files
cp patched/ mame/src/mame/seibu/
cd mame && make SUBTARGET=cupsoc SOURCES=src/mame/seibu/legionna.cpp -j8 NOWERROR=1 TOOLS=0 REGENIE=1

The result is cupsoc.exe (MAME with only the legionna.cpp games). Rename it mame.exe.

What the patch changes

patch/apply_patch.py edits seibucop.cpp, seibucop.h, seibucop_cmd.ipp, seibucop_dma.ipp.
Every edit asserts on its anchor text, so it refuses to half-apply to a different MAME version.
The behavioural differences (13 items, e.g. the 16.16 multiplier commands 5105/f105/5905 that
MAME left unimplemented, d104, the latched distance for 3bb0, angle write rules, the depth sort
key) are documented in docs/01_cop3_diff.md (Korean) and in the comments of the patched code.

Sharing what you built
- The mame.exe you build is GPL software (MAME plus this GPL-3 patch). You may pass it on, but
  then the GPL requires you to provide the source as well: give people this kit (it contains
  the patch and fetches the MAME 0.289 source) rather than the bare exe. Building it for your
  own use carries no obligation at all.
- Never bundle or share the game ROM with it. That is a copyright violation regardless of the
  GPL. Everybody must use their own copy.

License and credits

- The patch (this repository) is released under the GNU GPL v3 or later (see LICENSE),
  because the coprocessor behaviour is ported from rmonic79's GPL-3 MiSTer core.
  Credit: rmonic79 - the COP3 (SEI300) analysis and hardware verification.
- MAME is (c) MAMEdev and contributors, GPL-2.0-or-later / BSD-3-Clause (https://www.mamedev.org).
  This kit downloads it from its official repository unchanged.
- Seibu Cup Soccer is (c) 1992 Seibu Kaihatsu. No ROMs are included or linked; use your own.
- Netplay launcher and homepage: https://seibucup.online

---

한국어

MAME은 아직 세이부 컵 사커(cupsoc)를 "보호칩 미구현 / 동작 안 함"으로 표시합니다. 게임이
의존하는 SEI300(COP3) 보조 프로세서 명령이 비어 있거나 틀리기 때문입니다. 이 패치는 MAME의
src/mame/seibu/ 파일 4개를 고친 판으로 바꿉니다. 내용은 실제 기판으로 검증된
rmonic79 님의 MiSTer FPGA 코어 (https://github.com/rmonic79/Arcade-SeibuCupSoccer_MiSTer)에서
옮겨 온 것입니다. 적용하면 게임이 정상적으로 됩니다(선수 방향, 공 접촉, 깊이 정렬, 경기 종료까지).

여기에는 MAME 실행 파일이 없습니다. 각자 자기 PC에서 빌드합니다.

한 번에 하기 (Windows 10/11 64비트)

1. 이 폴더를 넷플레이 패키지 안(bin\ 옆)에 풉니다. MAME만 필요하면 아무 데나 풀어도 됩니다.
2. setup_mame.cmd 를 더블클릭합니다.
3. 기다립니다. 무료 컴파일러 환경 MSYS2를 이 폴더 안(msys64\)에 내려받고(시스템에는 아무것도
   설치하지 않음), MAME 0.289 소스(약 2 GB)를 받아 패치를 적용한 뒤 이 게임 드라이버만
   컴파일합니다(CPU에 따라 5~40분). 완성된 mame.exe는 ..\bin\(또는 out\)에 놓입니다.

작업 중 약 6 GB의 여유 공간이 필요하며, 끝나면 컴파일러와 소스는 자동으로 지워지고 mame.exe만 남습니다. 폴더는
공백이나 한글이 없는 단순한 경로(예: C:\seibucup\)에 두세요. 아무것도 업로드하지 않습니다.
네트워크가 끊겨 실패하면 스크립트를 다시 실행하면 이어서 진행됩니다.

빌드한 결과물을 남에게 줄 때
- 만들어진 mame.exe는 GPL 프로그램(MAME + 이 GPL-3 패치)입니다. 남에게 줄 수는 있지만, 그때는
  GPL에 따라 소스도 함께 제공해야 합니다. exe만 따로 주지 말고 이 키트를 주세요(패치가 들어 있고
  MAME 0.289 소스를 직접 받습니다). 본인이 만들어 본인만 쓰는 데에는 아무 의무가 없습니다.
- 게임 롬을 같이 넣어 배포하는 것은 GPL과 상관없이 저작권 침해입니다. 각자 자기 롬을 쓰세요.

알아 두면 좋은 것
- 관리자 권한은 필요 없습니다. 시스템에는 아무것도 설치하지 않고 모두 이 폴더 안에서만 처리합니다.
  다만 C:\Program Files 같은 보호된 위치에는 두지 마세요. C:\seibucup 같은 일반 폴더면 됩니다.
- 스크립트나 키트가 내려받는 MSYS2 설치 파일에 대해 Windows가 파란 "PC 보호"(SmartScreen) 창을 띄울
  수 있습니다. "추가 정보" → "실행"을 누르면 됩니다. 일부 백신은 컴파일을 느리게 만드는데 정상입니다.

라이선스

- 이 패치는 GNU GPL v3 이상입니다(LICENSE). COP3 동작이 rmonic79 님의 GPL-3 코어에서
  옮겨 온 것이기 때문입니다. 크레딧: rmonic79 - COP3(SEI300) 분석과 실기 검증.
- MAME은 MAMEdev와 기여자들의 저작물(GPL-2.0-or-later / BSD-3-Clause)이며, 이 키트는 공식
  저장소에서 그대로 내려받습니다.
- 세이부 컵 사커는 (c) 1992 세이부 카이하츠. 롬은 포함하지도 링크하지도 않습니다.
- 넷플레이 런처와 홈페이지: https://seibucup.online
