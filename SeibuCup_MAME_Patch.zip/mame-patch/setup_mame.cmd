@echo off
rem ============================================================================
rem  Seibu Cup Soccer - build your own MAME with the COP3 fixes (one click)
rem
rem  Everything happens inside THIS folder, nothing is installed system-wide:
rem    1. msys64\      the free compiler environment MAME uses (downloaded here, ~100 MB, unpacks to ~600 MB)
rem    2. packages     gcc/python/git into that msys64 (~1 GB)
rem    3. mame-src\    the MAME 0.289 source (~2 GB, one tag only)
rem    4. the Seibu Cup Soccer COP3 patch is applied (GPL-3)
rem    5. only this game's driver is compiled (5-40 minutes)
rem    6. mame.exe goes to ..\bin\ (netplay package) or out\
rem
rem  Needs about 6 GB free while it works and an internet connection; the compiler and the
rem  source are deleted again at the end, only mame.exe stays. Run again to resume after a failure.
rem  Log: setup_mame.log next to this file.
rem ============================================================================
setlocal EnableDelayedExpansion
set "KIT=%~dp0"
set "KIT=%KIT:~0,-1%"
set "LOG=%KIT%\setup_mame.log"
echo [setup] %DATE% %TIME% start > "%LOG%"
echo.
echo  Seibu Cup Soccer - MAME build kit
echo  folder: %KIT%
echo.

rem ---- the compiler environment cannot live in a path with spaces or non-ASCII characters
powershell -NoProfile -ExecutionPolicy Bypass -Command "if ('%KIT%' -match '[^\x21-\x7E]') { exit 1 } else { exit 0 }" >nul 2>&1
if errorlevel 1 (
  echo  This folder's path contains a space or a non-English character:
  echo     %KIT%
  echo  The compiler environment cannot work there. Move the whole folder to a simple path
  echo  such as  C:\seibucup\mame-patch  and run this script again.
  goto fail
)

rem ---- 1. MSYS2 inside the kit --------------------------------------------------
set "MSYS=%KIT%\msys64"
if exist "%MSYS%\usr\bin\bash.exe" goto have_msys
if not "%MSYS2_ROOT%"=="" if exist "%MSYS2_ROOT%\usr\bin\bash.exe" ( set "MSYS=%MSYS2_ROOT%" & goto have_msys )
echo  1/6 downloading the compiler environment (MSYS2, about 100 MB)...
echo [setup] 1/6 downloading msys2 base >> "%LOG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { [Net.ServicePointManager]::SecurityProtocol = 'Tls12'; $r = Invoke-RestMethod 'https://api.github.com/repos/msys2/msys2-installer/releases/latest'; $a = $r.assets | Where-Object { $_.name -like 'msys2-base-x86_64-*.sfx.exe' } | Select-Object -First 1; if (-not $a) { exit 2 }; Write-Host ('     ' + $a.name); Invoke-WebRequest $a.browser_download_url -OutFile '%KIT%\msys2-base.sfx.exe' }" >> "%LOG%" 2>&1
if not exist "%KIT%\msys2-base.sfx.exe" (
  echo  Download failed. Check the internet connection and run this script again.
  goto fail
)
echo      unpacking...
"%KIT%\msys2-base.sfx.exe" -y -o"%KIT%" >> "%LOG%" 2>&1
del /q "%KIT%\msys2-base.sfx.exe" >nul 2>&1
if not exist "%MSYS%\usr\bin\bash.exe" (
  echo  Unpacking MSYS2 failed. Details: %LOG%
  goto fail
)
echo      first-time setup and update (a few minutes)...
echo [setup] msys2 first run + update >> "%LOG%"
set MSYSTEM=MSYS
set CHERE_INVOKING=1
set MSYS2_PATH_TYPE=minimal
"%MSYS%\usr\bin\bash.exe" -lc "exit" >> "%LOG%" 2>&1
"%MSYS%\usr\bin\bash.exe" -lc "pacman -Syu --noconfirm" >> "%LOG%" 2>&1
"%MSYS%\usr\bin\bash.exe" -lc "pacman -Su --noconfirm" >> "%LOG%" 2>&1
:have_msys
echo  MSYS2: %MSYS%
echo [setup] msys2 at %MSYS% >> "%LOG%"

rem ---- 2..6 inside the MinGW64 shell ------------------------------------------
set MSYSTEM=MINGW64
set CHERE_INVOKING=1
set MSYS2_PATH_TYPE=minimal
set "SCNP_KIT=%KIT%"
"%MSYS%\usr\bin\bash.exe" -l "%KIT%\setup_mame.sh"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" goto fail

echo.
echo  ===== BUILD DONE =====
if exist "%KIT%\..\bin\mame.exe" ( echo  mame.exe is in place: %KIT%\..\bin\mame.exe ) else ( echo  mame.exe is in %KIT%\out\mame.exe - copy it into the netplay package's bin\ folder. )
echo.
echo  cleaning up the compiler and the source (about 5 GB) - this takes a minute...
echo [setup] cleanup >> "%LOG%"
if exist "%KIT%\mame-src" rmdir /s /q "%KIT%\mame-src" >> "%LOG%" 2>&1
if exist "%KIT%\work" rmdir /s /q "%KIT%\work" >> "%LOG%" 2>&1
if "%MSYS%"=="%KIT%\msys64" if exist "%KIT%\msys64" rmdir /s /q "%KIT%\msys64" >> "%LOG%" 2>&1
echo  done. Only mame.exe and this kit remain.
echo [setup] done >> "%LOG%"
pause
exit /b 0

:fail
echo.
echo  Something went wrong. Details: %LOG%
echo [setup] FAILED >> "%LOG%"
pause
exit /b 1
