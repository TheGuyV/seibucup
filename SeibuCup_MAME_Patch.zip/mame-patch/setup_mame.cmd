@echo off
rem ============================================================================
rem  Seibu Cup Soccer - build your own MAME with the COP3 fixes (one click)
rem
rem  Everything happens inside THIS folder, nothing is installed system-wide:
rem    1. msys64\      the free compiler environment MAME uses (downloaded here, ~100 MB, unpacks to ~600 MB)
rem    2. packages     gcc/python/git into that msys64 (~1 GB)
rem    3. mame-src\    the MAME 0.289 source (~2 GB, one tag only)
rem    4. the Seibu Cup Soccer COP3 patch is applied (GPL-3)
rem    5. only this game's driver is compiled (5-40 minutes)
rem    6. mame.exe goes to ..\bin\ (netplay package) or out\ (then it asks for the package folder)
rem
rem  Needs about 6 GB free while it works and an internet connection; the compiler and the
rem  source are deleted again at the end, only mame.exe stays. Run again to resume after a failure.
rem  Log: setup_mame.log next to this file.
rem  Messages follow the Windows display language (Korean or English). To force one:
rem    set SCNP_LANG=en   (or ko)   before running this script.
rem ============================================================================
setlocal EnableDelayedExpansion
set "KIT=%~dp0"
set "KIT=%KIT:~0,-1%"
set "LOG=%KIT%\setup_mame.log"

rem ---- language: Windows display language, or SCNP_LANG=ko/en to override ---------
set "L=en"
if /i "%SCNP_LANG%"=="ko" set "L=ko"
if /i "%SCNP_LANG%"=="en" set "L=en"
if not "%SCNP_LANG%"=="" goto lang_done
for /f "usebackq delims=" %%a in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$l = (Get-ItemProperty 'HKCU:\Control Panel\Desktop' -Name PreferredUILanguages -ErrorAction SilentlyContinue).PreferredUILanguages | Select-Object -First 1; if (-not $l) { try { $l = (Get-WinUserLanguageList)[0].LanguageTag } catch {} }; if (-not $l) { $l = (Get-UICulture).Name }; $l"`) do set "L=%%a"
set "L=%L:~0,2%"
if /i "%L%"=="ko" (set "L=ko") else (set "L=en")
:lang_done
set "SCNP_LANG=%L%"
rem this file is UTF-8; the Korean lines below only display right with the UTF-8 code page
if "%L%"=="ko" chcp 65001 >nul

if exist "%LOG%" copy /y "%LOG%" "%KIT%\setup_mame.prev.log" >nul 2>&1
echo [setup] %DATE% %TIME% start (lang %L%) > "%LOG%"
echo.
call :say "Seibu Cup Soccer - MAME build kit" "세이부 컵 사커 - MAME 빌드 키트"
call :say "folder: %KIT%" "폴더: %KIT%"
echo.

rem ---- the compiler environment cannot live in a path with spaces or non-ASCII characters
powershell -NoProfile -ExecutionPolicy Bypass -Command "if ('%KIT%' -match '[^\x21-\x7E]') { exit 1 } else { exit 0 }" >nul 2>&1
if errorlevel 1 (
  call :say "This folder's path contains a space or a non-English character:" "이 폴더의 경로에 공백이나 영문 이외의 문자가 있습니다:"
  echo     %KIT%
  call :say "The compiler environment cannot work there. Move the whole folder to a simple path" "컴파일 환경은 그런 경로에서 동작하지 않습니다. 폴더 전체를"
  call :say "such as  C:\seibucup\mame-patch  and run this script again." "C:\seibucup\mame-patch 같은 단순한 경로로 옮긴 뒤 이 스크립트를 다시 실행하세요."
  goto fail
)

rem ---- 1. MSYS2 inside the kit --------------------------------------------------
set "MSYS=%KIT%\msys64"
if exist "%MSYS%\usr\bin\bash.exe" goto have_msys
if not "%MSYS2_ROOT%"=="" if exist "%MSYS2_ROOT%\usr\bin\bash.exe" ( set "MSYS=%MSYS2_ROOT%" & goto have_msys )
call :say "1/6 downloading the compiler environment (MSYS2, about 100 MB)..." "1/6 컴파일 환경(MSYS2, 약 100 MB)을 내려받는 중..."
echo [setup] 1/6 downloading msys2 base >> "%LOG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { [Net.ServicePointManager]::SecurityProtocol = 'Tls12'; $r = Invoke-RestMethod 'https://api.github.com/repos/msys2/msys2-installer/releases/latest'; $a = $r.assets | Where-Object { $_.name -like 'msys2-base-x86_64-*.sfx.exe' } | Select-Object -First 1; if (-not $a) { exit 2 }; Write-Host ('     ' + $a.name); Invoke-WebRequest $a.browser_download_url -OutFile '%KIT%\msys2-base.sfx.exe' }" >> "%LOG%" 2>&1
if not exist "%KIT%\msys2-base.sfx.exe" (
  call :say "Download failed. Check the internet connection and run this script again." "내려받기에 실패했습니다. 인터넷 연결을 확인하고 이 스크립트를 다시 실행하세요."
  goto fail
)
call :say "    unpacking..." "    압축을 푸는 중..."
"%KIT%\msys2-base.sfx.exe" -y -o"%KIT%" >> "%LOG%" 2>&1
del /q "%KIT%\msys2-base.sfx.exe" >nul 2>&1
if not exist "%MSYS%\usr\bin\bash.exe" (
  call :say "Unpacking MSYS2 failed. Details: %LOG%" "MSYS2 압축 풀기에 실패했습니다. 자세한 내용: %LOG%"
  goto fail
)
call :say "    first-time setup and update (a few minutes)..." "    첫 설정과 업데이트 (몇 분 걸립니다)..."
echo [setup] msys2 first run + update >> "%LOG%"
set MSYSTEM=MSYS
set CHERE_INVOKING=1
set MSYS2_PATH_TYPE=minimal
"%MSYS%\usr\bin\bash.exe" -lc "exit" >> "%LOG%" 2>&1
"%MSYS%\usr\bin\bash.exe" -lc "pacman -Syu --noconfirm" >> "%LOG%" 2>&1
"%MSYS%\usr\bin\bash.exe" -lc "pacman -Su --noconfirm" >> "%LOG%" 2>&1
:have_msys
echo  MSYS2: %MSYS%
echo [setup] msys2 at %MSYS% >> "%LOG%"

rem ---- 2..6 inside the MinGW64 shell ------------------------------------------
set MSYSTEM=MINGW64
set CHERE_INVOKING=1
set MSYS2_PATH_TYPE=minimal
set "SCNP_KIT=%KIT%"
"%MSYS%\usr\bin\bash.exe" -l "%KIT%\setup_mame.sh"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" goto fail

echo.
call :say "===== BUILD DONE =====" "===== 빌드 완료 ====="
if exist "%KIT%\..\bin\mame.exe" call :say "mame.exe is in place: %KIT%\..\bin\mame.exe" "mame.exe 를 제자리에 넣었습니다: %KIT%\..\bin\mame.exe"
if not exist "%KIT%\..\bin\mame.exe" call :askpkg
echo.
call :say "cleaning up the compiler and the source (about 5 GB) - this takes a minute..." "컴파일러와 소스(약 5 GB)를 정리하는 중 - 1분쯤 걸립니다..."
echo [setup] cleanup >> "%LOG%"
if exist "%KIT%\mame-src" rmdir /s /q "%KIT%\mame-src" >> "%LOG%" 2>&1
if exist "%KIT%\work" rmdir /s /q "%KIT%\work" >> "%LOG%" 2>&1
if "%MSYS%"=="%KIT%\msys64" if exist "%KIT%\msys64" rmdir /s /q "%KIT%\msys64" >> "%LOG%" 2>&1
call :say "done. Only mame.exe and this kit remain." "끝났습니다. mame.exe 와 이 키트만 남았습니다."
echo [setup] done >> "%LOG%"
pause
exit /b 0

rem ---- print the English or the Korean text -------------------------------------
:say
if "%L%"=="ko" echo  %~2
if not "%L%"=="ko" echo  %~1
goto :eof

rem ---- the kit is not inside the netplay package: ask where the package is and put mame.exe into its bin\ ----
:askpkg
set TRIES=0
if "%L%"=="ko" (set "P_PKG=  패키지 폴더: ") else (set "P_PKG=  package folder: ")
:askpkg_again
set "PKG="
set "PKGDIR="
echo.
call :say "mame.exe is built: %KIT%\out\mame.exe" "mame.exe 가 만들어졌습니다: %KIT%\out\mame.exe"
call :say "Where is the netplay package (the folder that holds SeibuCupNetplay.exe)?" "넷플레이 패키지(SeibuCupNetplay.exe 가 있는 폴더)는 어디에 있나요?"
call :say "Drag that folder (or SeibuCupNetplay.exe) onto this window and press Enter." "그 폴더(또는 SeibuCupNetplay.exe)를 이 창에 끌어다 놓고 Enter 를 누르세요."
call :say "Just press Enter to keep mame.exe in out\ and copy it yourself later." "그냥 Enter 를 누르면 mame.exe 는 out\ 에 남고, 나중에 직접 복사하면 됩니다."
set /p "PKG=%P_PKG%"
if not defined PKG goto :keepout
set "PKG=%PKG:"=%"
if exist "%PKG%\SeibuCupNetplay.exe" set "PKGDIR=%PKG%"
if defined PKGDIR goto :copypkg
for %%I in ("%PKG%") do if /i "%%~nxI"=="SeibuCupNetplay.exe" if exist "%PKG%" set "PKGDIR=%%~dpI"
if defined PKGDIR goto :copypkg
set /a TRIES+=1
call :say "SeibuCupNetplay.exe was not found there." "그곳에 SeibuCupNetplay.exe 가 없습니다."
if %TRIES% LSS 3 goto :askpkg_again
:keepout
call :say "ok - mame.exe stays in %KIT%\out\ - copy it into the package's bin\ folder yourself." "알겠습니다 - mame.exe 는 %KIT%\out\ 에 있습니다. 패키지의 bin\ 폴더에 직접 복사하세요."
goto :eof
:copypkg
if "%PKGDIR:~-1%"=="\" set "PKGDIR=%PKGDIR:~0,-1%"
if not exist "%PKGDIR%\bin" mkdir "%PKGDIR%\bin"
copy /y "%KIT%\out\mame.exe" "%PKGDIR%\bin\mame.exe" >nul
if errorlevel 1 goto :copyfail
call :say "mame.exe is in place: %PKGDIR%\bin\mame.exe" "mame.exe 를 제자리에 넣었습니다: %PKGDIR%\bin\mame.exe"
echo [setup] copied to %PKGDIR%\bin\mame.exe >> "%LOG%"
goto :eof
:copyfail
call :say "copy failed - copy %KIT%\out\mame.exe into %PKGDIR%\bin\ yourself." "복사에 실패했습니다 - %KIT%\out\mame.exe 를 %PKGDIR%\bin\ 에 직접 복사하세요."
goto :eof

:fail
echo.
call :say "Something went wrong. Details: %LOG%" "문제가 생겼습니다. 자세한 내용: %LOG%"
echo [setup] FAILED >> "%LOG%"
pause
exit /b 1
