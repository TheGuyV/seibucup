#!/bin/bash
# Runs inside MSYS2 MinGW64 (started by setup_mame.cmd). Steps 2..6 of the one-click build.
set -o pipefail
KIT="$(cygpath -u "$SCNP_KIT")"
LOG="$KIT/setup_mame.log"
SRC="$KIT/mame-src"
TAG="mame0289"
JOBS="${NUMBER_OF_PROCESSORS:-4}"
# each compiler process needs 1.5-2 GB at peak, so cap the thread count by RAM (8 GB PC -> 3 threads)
MEM_GB=$(powershell.exe -NoProfile -Command "[int]((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)" 2>/dev/null | tr -d '\r ')
case "$MEM_GB" in ''|*[!0-9]*) MEM_GB=8 ;; esac
MAXJ=$(( MEM_GB * 2 / 5 )); [ "$MAXJ" -lt 1 ] && MAXJ=1
[ "$JOBS" -gt "$MAXJ" ] && JOBS=$MAXJ
say() { echo "  $*"; echo "[setup] $*" >> "$LOG"; }

say "2/6 compiler packages (about 1 GB the first time, skipped if already there)..."
PKGS="git make mingw-w64-x86_64-gcc mingw-w64-x86_64-python mingw-w64-x86_64-lld mingw-w64-x86_64-libc++"
if ! pacman -S --needed --noconfirm $PKGS >> "$LOG" 2>&1; then
  pacman -Sy --noconfirm >> "$LOG" 2>&1
  pacman -S --needed --noconfirm $PKGS >> "$LOG" 2>&1 || { say "package install failed - check the internet connection and run the script again"; exit 1; }
fi

say "3/6 MAME $TAG source (about 2 GB the first time)..."
if [ ! -f "$SRC/makefile" ]; then
  rm -rf "$SRC"
  say "    downloading (no progress shown here; the log grows meanwhile)..."
  # git exits non-zero for the annotated release tag ("not a commit" warning) even though the
  # checkout is complete, so success is judged by the tree being there, not by the exit code
  git -c advice.detachedHead=false clone --depth 1 --branch "$TAG" https://github.com/mamedev/mame.git "$SRC" >> "$LOG" 2>&1
fi
[ -f "$SRC/makefile" ] && [ -f "$SRC/src/mame/seibu/seibucop.cpp" ] || { rm -rf "$SRC"; say "MAME source download did not complete (network?) - run the script again to retry"; exit 1; }

say "4/6 applying the Seibu Cup Soccer COP3 patch..."
SEIBU="$SRC/src/mame/seibu"
if grep -q "cop_mul_16_16" "$SEIBU/seibucop_cmd.ipp" 2>/dev/null; then
  say "    already applied"
else
  mkdir -p "$KIT/work/pristine" "$KIT/work/patched"
  for f in seibucop.cpp seibucop.h seibucop_cmd.ipp seibucop_dma.ipp; do cp "$SEIBU/$f" "$KIT/work/pristine/$f"; done
  python "$KIT/patch/apply_patch.py" "$KIT/work/pristine" "$KIT/work/patched" >> "$LOG" 2>&1 \
    || { say "the patch does not fit this MAME source (see $LOG) - it is written for $TAG"; exit 1; }
  for f in seibucop.cpp seibucop.h seibucop_cmd.ipp seibucop_dma.ipp; do cp "$KIT/work/patched/$f" "$SEIBU/$f"; done
fi

say "5/6 compiling (this game's driver only) with $JOBS threads - 5 to 40 minutes, the PC will be busy..."
cd "$SRC" || exit 1
make SUBTARGET=cupsoc SOURCES=src/mame/seibu/legionna.cpp -j"$JOBS" NOWERROR=1 TOOLS=0 REGENIE=1 >> "$LOG" 2>&1 \
  || { say "    the parallel compile stopped (usually out of memory) - continuing with 1 thread, only the rest is compiled..."
       echo "[setup] retrying make with -j1" >> "$LOG"
       make SUBTARGET=cupsoc SOURCES=src/mame/seibu/legionna.cpp -j1 NOWERROR=1 TOOLS=0 >> "$LOG" 2>&1 \
         || { say "compile failed - see $LOG (close other programs and run the script again; it resumes where it stopped)"; exit 1; }; }
[ -f "$SRC/cupsoc.exe" ] || { say "compile finished but cupsoc.exe is missing - see $LOG"; exit 1; }

say "6/6 installing mame.exe..."
if [ -d "$KIT/../bin" ]; then
  cp -f "$SRC/cupsoc.exe" "$KIT/../bin/mame.exe" && say "    -> $(cygpath -w "$KIT/../bin/mame.exe")"
else
  mkdir -p "$KIT/out" && cp -f "$SRC/cupsoc.exe" "$KIT/out/mame.exe" && say "    -> $(cygpath -w "$KIT/out/mame.exe")"
fi
say "all done"
exit 0
