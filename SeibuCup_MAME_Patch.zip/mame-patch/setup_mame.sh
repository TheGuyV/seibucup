#!/bin/bash
# Runs inside MSYS2 MinGW64 (started by setup_mame.cmd). Steps 2..6 of the one-click build.
# Messages: say "English" "한국어" - the Korean text is shown when setup_mame.cmd passed SCNP_LANG=ko
# (Windows display language); the log always gets the English line.
set -o pipefail
KIT="$(cygpath -u "$SCNP_KIT")"
LOG="$KIT/setup_mame.log"
SRC="$KIT/mame-src"
TAG="mame0289"
JOBS="${NUMBER_OF_PROCESSORS:-4}"
# each compiler process needs 1.5-2 GB at peak, so cap the thread count by RAM (8 GB PC -> 3 threads)
MEM_GB=$(powershell.exe -NoProfile -Command "[int]((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)" 2>/dev/null | tr -d '\r ')
case "$MEM_GB" in ''|*[!0-9]*) MEM_GB=8 ;; esac
MAXJ=$(( MEM_GB * 2 / 5 )); [ "$MAXJ" -lt 1 ] && MAXJ=1
[ "$JOBS" -gt "$MAXJ" ] && JOBS=$MAXJ
say() {
  if [ "$SCNP_LANG" = "ko" ] && [ -n "$2" ]; then echo "  $2"; else echo "  $1"; fi
  echo "[setup] $1" >> "$LOG"
}

say "2/6 compiler packages (about 1 GB the first time, skipped if already there)..." \
    "2/6 컴파일러 패키지 (처음에는 약 1 GB, 이미 있으면 건너뜀)..."
PKGS="git make mingw-w64-x86_64-gcc mingw-w64-x86_64-python mingw-w64-x86_64-lld mingw-w64-x86_64-libc++"
if ! pacman -S --needed --noconfirm $PKGS >> "$LOG" 2>&1; then
  pacman -Sy --noconfirm >> "$LOG" 2>&1
  pacman -S --needed --noconfirm $PKGS >> "$LOG" 2>&1 \
    || { say "package install failed - check the internet connection and run the script again" \
             "패키지 설치에 실패했습니다 - 인터넷 연결을 확인하고 스크립트를 다시 실행하세요"; exit 1; }
fi

say "3/6 MAME $TAG source (about 2 GB the first time)..." \
    "3/6 MAME $TAG 소스 (처음에는 약 2 GB)..."
if [ ! -f "$SRC/makefile" ]; then
  rm -rf "$SRC"
  say "    downloading (no progress shown here; the log grows meanwhile)..." \
      "    내려받는 중 (진행 표시는 없고, 그동안 로그 파일이 커집니다)..."
  # git exits non-zero for the annotated release tag ("not a commit" warning) even though the
  # checkout is complete, so success is judged by the tree being there, not by the exit code
  git -c advice.detachedHead=false clone --depth 1 --branch "$TAG" https://github.com/mamedev/mame.git "$SRC" >> "$LOG" 2>&1
fi
[ -f "$SRC/makefile" ] && [ -f "$SRC/src/mame/seibu/seibucop.cpp" ] \
  || { rm -rf "$SRC"; say "MAME source download did not complete (network?) - run the script again to retry" \
                          "MAME 소스 내려받기가 끝나지 않았습니다 (네트워크?) - 스크립트를 다시 실행하면 재시도합니다"; exit 1; }

say "4/6 applying the Seibu Cup Soccer COP3 patch..." \
    "4/6 세이부 컵 사커 COP3 패치를 적용하는 중..."
SEIBU="$SRC/src/mame/seibu"
if grep -q "cop_mul_16_16" "$SEIBU/seibucop_cmd.ipp" 2>/dev/null; then
  say "    already applied" "    이미 적용되어 있음"
else
  mkdir -p "$KIT/work/pristine" "$KIT/work/patched"
  for f in seibucop.cpp seibucop.h seibucop_cmd.ipp seibucop_dma.ipp; do cp "$SEIBU/$f" "$KIT/work/pristine/$f"; done
  python "$KIT/patch/apply_patch.py" "$KIT/work/pristine" "$KIT/work/patched" >> "$LOG" 2>&1 \
    || { say "the patch does not fit this MAME source (see $LOG) - it is written for $TAG" \
             "이 MAME 소스에는 패치가 맞지 않습니다 ($LOG 참고) - 이 패치는 $TAG 용입니다"; exit 1; }
  for f in seibucop.cpp seibucop.h seibucop_cmd.ipp seibucop_dma.ipp; do cp "$KIT/work/patched/$f" "$SEIBU/$f"; done
fi

say "5/6 compiling (this game's driver only) with $JOBS threads - 5 to 40 minutes, the PC will be busy..." \
    "5/6 컴파일 중 (이 게임의 드라이버만) - 스레드 $JOBS 개, 5~40분, 그동안 PC 가 바쁩니다..."
cd "$SRC" || exit 1
make SUBTARGET=cupsoc SOURCES=src/mame/seibu/legionna.cpp -j"$JOBS" NOWERROR=1 TOOLS=0 REGENIE=1 >> "$LOG" 2>&1 \
  || { say "    the parallel compile stopped (usually out of memory) - continuing with 1 thread, only the rest is compiled..." \
           "    병렬 컴파일이 멈췄습니다 (대개 메모리 부족) - 1 스레드로 나머지만 이어서 컴파일합니다..."
       echo "[setup] retrying make with -j1" >> "$LOG"
       make SUBTARGET=cupsoc SOURCES=src/mame/seibu/legionna.cpp -j1 NOWERROR=1 TOOLS=0 >> "$LOG" 2>&1 \
         || { say "compile failed - see $LOG (close other programs and run the script again; it resumes where it stopped)" \
                  "컴파일에 실패했습니다 - $LOG 참고 (다른 프로그램을 닫고 스크립트를 다시 실행하세요. 멈춘 곳부터 이어집니다)"; exit 1; }; }
[ -f "$SRC/cupsoc.exe" ] \
  || { say "compile finished but cupsoc.exe is missing - see $LOG" \
           "컴파일은 끝났지만 cupsoc.exe 가 없습니다 - $LOG 참고"; exit 1; }

say "6/6 installing mame.exe..." "6/6 mame.exe 를 설치하는 중..."
if [ -d "$KIT/../bin" ]; then
  cp -f "$SRC/cupsoc.exe" "$KIT/../bin/mame.exe" && say "    -> $(cygpath -w "$KIT/../bin/mame.exe")"
else
  mkdir -p "$KIT/out" && cp -f "$SRC/cupsoc.exe" "$KIT/out/mame.exe" && say "    -> $(cygpath -w "$KIT/out/mame.exe")"
fi
say "all done" "모두 끝났습니다"
exit 0
